package cybersoft.javabackend.springbootdemo.controller;

import org.apache.tomcat.jni.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cybersoft.javabackend.springbootdemo.model.Home;

@RestController
@RequestMapping ("/home")
		public class HomeController {

	@GetMapping("")
	public Object home() {
		return new Home();
	}
	
	@GetMapping ("/message")
	public Object message () {
		return "welcome to spring boot application";
	}
}
